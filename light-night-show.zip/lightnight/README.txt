LIGHT-NIGHT-SHOW

PHP-Webserver erforderlich (PHP 7.4+). Alle Dateien hochladen; data/ und uploads/ müssen beschreibbar sein.
Admin: /admin.php
Benutzername: z3nn
Passwort: Jermyistcool123

Das mitgelieferte Bild wird von index.php automatisch als Base64-Hintergrund eingebettet. Der Admin kann Texte, Button, Akzentfarbe, Abdunklung und Hintergrundbild ändern. HTTPS für eine echte öffentliche Seite aktivieren.
